<?php

if (!defined('_PS_VERSION_'))
    return false;


class CommentProduct extends Module
{
    public function __construct()
    {
        $this->name = 'commentproduct';
        $this->author = 'Lloyd Alcantara';
        $this->version = '1.0';

        $this->bootstrap = true;
        parent::__construct();

        $this->displayName = $this->trans('Product comment', array(), 'Modules.CommentProduct.Admin');
        $this->description = $this->trans ('Allows users to comment on the product', array(), 'Modules.CommentProduct.Admin');

        $this->ps_versions_compliancy = array('min' => '1.7', 'max' => _PS_VERSION_);

        $this->templateFile = 'module:commentProduct/views/templates/hook/CommentProduct.tpl';
    }
}